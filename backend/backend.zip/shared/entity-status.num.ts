export enum status {
  ACTIVE = 'ACTIVE',
  INACTIVE = 'INACTIVE',
}
