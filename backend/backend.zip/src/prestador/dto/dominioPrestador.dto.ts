import { IsObject } from "class-validator";
import { DominioEntity } from "src/sic/dominio.entity";

export class DominioPrestadorDto {

    pre_cod_habilitacion: string

    dom_id: number;
}