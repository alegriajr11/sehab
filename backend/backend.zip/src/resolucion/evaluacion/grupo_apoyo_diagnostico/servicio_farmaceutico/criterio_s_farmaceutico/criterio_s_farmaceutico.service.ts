import { Injectable, InternalServerErrorException, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { MessageDto } from 'src/common/message.dto';
import { CriterioSerFarmaceuticoEntity } from '../criterios_s_farmaceutico.entity';
import { ServFarmaceuticoEntity } from '../servicio_farmaceutico.entity';
import { CriterioSerFarmaceuticoRepository } from '../criterios_s_farmaceutico.repository';
import { ServFarmaceuticoRepository } from '../servicio_farmaceutico.repository';
import { CriterioSerFarmaceuticoDto } from 'src/resolucion/dtos/evaluacion_dtos/grupo_apoyo_diagnostico_dtos/servicio_farmaceutico_dto/criterios_s_farmaceutico.dto';

@Injectable()
export class CriterioSFarmaceuticoService {


    constructor(
        @InjectRepository(CriterioSerFarmaceuticoEntity)
        private readonly criterioSerFarmaceuticoRepository: CriterioSerFarmaceuticoRepository,
        @InjectRepository(ServFarmaceuticoEntity)
        private readonly servFarmaceuticoRepository: ServFarmaceuticoRepository,
    ) { }


    //LISTANDO CRITERIOS POR ESTANDAR
    async getCriterioForEstandar(id: number): Promise<CriterioSerFarmaceuticoEntity[]> {
        const cri_farma = await this.criterioSerFarmaceuticoRepository.createQueryBuilder('criterio')
            .select(['criterio', 'ser_farmaceutico.ser_farma_nombre_estandar'])
            .innerJoin('criterio.ser_farmaceutico', 'ser_farmaceutico')
            .where('ser_farmaceutico.ser_farma_id = :farm_est', { farm_est: id })
            .getMany()
        if (!cri_farma) throw new NotFoundException(new MessageDto('No Existe en la lista'))
        return cri_farma
    }

    //CREAR CRITERIO
    async create(ser_farma_id: number, dto: CriterioSerFarmaceuticoDto): Promise<any> {
        const servifarma = await this.servFarmaceuticoRepository.findOne({ where: { ser_farma_id: ser_farma_id } });
        if (!servifarma) throw new InternalServerErrorException(new MessageDto('El Estandar no ha sido creado'))
        //CREAMOS EL DTO PARA TRANSFERIR LOS DATOS
        const criterioservifarma = this.criterioSerFarmaceuticoRepository.create(dto)
        //ASIGNAMOS EL ESTANDAR AL CRITERIO
        criterioservifarma.ser_farmaceutico = servifarma
        //GUARDAR LOS DATOS EN LA BD
        await this.criterioSerFarmaceuticoRepository.save(criterioservifarma)
        return new MessageDto('El criterio ha sido Creado Correctamente');
    }

    //ENCONTRAR POR ID - CRITERIO SERVICIO FARMACEUTICO
    async findById(criser_farm_id: number): Promise<CriterioSerFarmaceuticoEntity> {
        const criterio_ser_farm = await this.criterioSerFarmaceuticoRepository.findOne({ where: { criser_farm_id } });
        if (!criterio_ser_farm) {
            throw new NotFoundException(new MessageDto('El Criterio No Existe'));
        }
        return criterio_ser_farm;
    }

    //ELIMINAR CRITERIO SERVICIO FARMACEUTICO
    async delete(id: number): Promise<any> {
        const criterio_ser_farm = await this.findById(id);
        await this.criterioSerFarmaceuticoRepository.delete(criterio_ser_farm.criser_farm_id)
        return new MessageDto(`Criterio Eliminado`);
    }

    //ACTUALIZAR CRITERIOS SERVICIO FARMACEUTICO
    async updateFarma(id: number, dto: CriterioSerFarmaceuticoDto): Promise<any> {
        const criterio_ser_farm = await this.findById(id);
        if (!criterio_ser_farm) {
            throw new NotFoundException(new MessageDto('El criterio no existe'))
        }
        dto.criser_farm_modalidad ? criterio_ser_farm.criser_farm_modalidad = dto.criser_farm_modalidad : criterio_ser_farm.criser_farm_modalidad = criterio_ser_farm.criser_farm_modalidad;
        dto.criser_farm_complejidad ? criterio_ser_farm.criser_farm_complejidad = dto.criser_farm_complejidad : criterio_ser_farm.criser_farm_complejidad = criterio_ser_farm.criser_farm_complejidad;
        criterio_ser_farm.criser_farm_articulo = dto.criser_farm_articulo !== undefined ? dto.criser_farm_articulo : "";
        criterio_ser_farm.criser_farm_seccion = dto.criser_farm_seccion !== undefined ? dto.criser_farm_seccion : "";
        criterio_ser_farm.criser_farm_apartado = dto.criser_farm_apartado !== undefined ? dto.criser_farm_apartado : "";
        dto.criser_farm_nombre_criterio ? criterio_ser_farm.criser_farm_nombre_criterio = dto.criser_farm_nombre_criterio : criterio_ser_farm.criser_farm_nombre_criterio = criterio_ser_farm.criser_farm_nombre_criterio;

        await this.criterioSerFarmaceuticoRepository.save(criterio_ser_farm);

        return new MessageDto(`El criterio ha sido Actualizado`);

    }
}
