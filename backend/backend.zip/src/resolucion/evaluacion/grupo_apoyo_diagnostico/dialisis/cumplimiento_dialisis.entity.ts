/* eslint-disable prettier/prettier */
import { PrestadorEntity } from "src/prestador/prestador.entity";
import { Column, Entity, JoinColumn, JoinTable, ManyToMany, ManyToOne, OneToMany, OneToOne, PrimaryGeneratedColumn } from "typeorm";
import { CriterioDialisisEntity } from "./criterio_dialisis.entity";


// import { CumplimientoEstandarSicEntity } from "./cumplimientoestandar.entity";



@Entity({ name: 'cumplimiento_dialisis' })
export class CumplimientoDialisisEntity {
    @PrimaryGeneratedColumn('increment')
    cump_dial_id: number;

    @Column({ type: 'varchar', length: 10, nullable: false, unique: true })
    cump_dial_cumple: string;

    @Column({ type: 'varchar', length: 60, nullable: false, unique: false })
    cump_dial_hallazgo: string;

    @Column({ type: 'varchar', length: 60, nullable: false, unique: false })
    cump_dial_accion: string;

    @Column({ type: 'varchar', length: 200, nullable: false, unique: false })
    cump_dial_responsable: string;

    @Column({ type: 'date', nullable: false, unique: false })
    cump_dial_fecha_limite: string;
    
    // Relacion MUCHOS a UNO CUMPLIMIENTO DIALISIS a PRESTADOR
    @ManyToOne(type => PrestadorEntity, prestador => prestador.cumplimiento_dialisis)
    prestador: PrestadorEntity

    @OneToOne(() => CriterioDialisisEntity)
    @JoinColumn()
    criterio_dialisis: CriterioDialisisEntity

}