/* eslint-disable prettier/prettier */
import { PrestadorEntity } from "src/prestador/prestador.entity";
import { Column, Entity, JoinColumn, JoinTable, ManyToMany, ManyToOne, OneToMany, OneToOne, PrimaryGeneratedColumn } from "typeorm";
import { CriterioVacunacionEntity } from "./criterio_vacunacion.entity";


// import { CumplimientoEstandarSicEntity } from "./cumplimientoestandar.entity";



@Entity({ name: 'cumplimiento_vacunacion' })
export class CumplimientoVacunacionEntity {
    @PrimaryGeneratedColumn('increment')
    cump_vac_id: number;

    @Column({ type: 'varchar', length: 10, nullable: false, unique: true })
    cump_vac_cumple: string;

    @Column({ type: 'varchar', length: 60, nullable: false, unique: false })
    cump_vac_hallazgo: string;

    @Column({ type: 'varchar', length: 60, nullable: false, unique: false })
    cump_vac_accion: string;

    @Column({ type: 'varchar', length: 200, nullable: false, unique: false })
    cump_vac_responsable: string;

    @Column({ type: 'date', nullable: false, unique: false })
    cump_vac_fecha_limite: string;

    //Relación MUCHOS a UNO CUMPLIMIENTO VACUNACION - PRESTAOR
    @ManyToOne(type => PrestadorEntity, prestador => prestador.cump_vacunacion)
    prestador: PrestadorEntity
    

    @OneToOne(() => CriterioVacunacionEntity)
    @JoinColumn()
    criterio_vacunacion: CriterioVacunacionEntity

}