/* eslint-disable prettier/prettier */
export interface PayloadInterface {
    usu_id: number;
    usu_nombre: string;
    usu_apellido: string;
    usu_nombreUsuario: string;
    usu_email: string;
    usu_estado: string;
    usu_roles: string[];
}