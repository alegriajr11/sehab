/* eslint-disable prettier/prettier */
export class TokenDto {
    token: string
}