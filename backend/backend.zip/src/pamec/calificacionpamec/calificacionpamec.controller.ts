import { Controller } from '@nestjs/common';

@Controller('calificacionpamec')
export class CalificacionpamecController {}
